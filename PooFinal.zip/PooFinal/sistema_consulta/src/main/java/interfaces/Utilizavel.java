package interfaces;

public interface Utilizavel {
    public void descricao();
}
