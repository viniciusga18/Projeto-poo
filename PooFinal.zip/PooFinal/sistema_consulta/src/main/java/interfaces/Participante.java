package interfaces;

public interface Participante {
    public void exibirInfo();
}
